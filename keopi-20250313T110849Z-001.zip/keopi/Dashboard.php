<?php
session_start();
include 'db_connection.php';

// Check if the user is an employee
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'employee') {
    echo "<script>alert('Access denied!'); window.location.href='Login.php';</script>";
    exit();
}

// Fetch all products
$sql_products = "SELECT * FROM products ORDER BY id DESC"; // Order by newest first
error_log("Fetching products with query: $sql_products");
$result_products = $conn->query($sql_products);
if (!$result_products) {
    error_log("Error fetching products: " . $conn->error);
    die("Error fetching products: " . $conn->error);
} else {
    $num_products = $result_products->num_rows;
    error_log("Number of products found: " . $num_products);
    if ($num_products === 0) {
        error_log("No products found in the database");
    } else {
        // Log the first product as a sample
        $first_product = $result_products->fetch_assoc();
        error_log("Sample product data: " . print_r($first_product, true));
        // Reset the pointer back to the beginning
        $result_products->data_seek(0);
    }
}

// Add this right before the table to see the data in the page
echo "<!-- Debug: Found $num_products products -->";

// Fetch all customers
$sql_customers = "SELECT * FROM users WHERE role = 'customer'";
$result_customers = $conn->query($sql_customers);
if (!$result_customers) {
    die("Error fetching customers: " . $conn->error);
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard - Manage Products & Customers</title>
    <link rel="stylesheet" href="Dashboard.css">
</head>

<body>

    <?php include 'components/Header.php'; ?>

    <!-- Logout Button -->
    <div class="logout-container">
        <a href="Logout.php" class="logout-btn">Logout</a>
    </div>

    <main class="user-management-container">
        <h1>Manage Products</h1>

        <!-- ADD NEW PRODUCT FORM -->
        <form action="ProductHandler.php" method="post" enctype="multipart/form-data" class="form-container">
            <input type="hidden" name="action" value="add">
            <input type="text" name="name" placeholder="Product Name" required>
            <select name="brand" required>
                <option value="">Select Brand</option>
                <option value="Samsung">Samsung</option>
                <option value="Apple">Apple</option>
                <option value="Oppo">Oppo</option>
                <option value="Redmi">Redmi</option>
                <option value="Oneplus">OnePlus</option>
            </select>
            <input type="number" name="price" placeholder="Price" required>
            <input type="number" name="stock" placeholder="Stock" required>
            <input type="file" name="image" required>
            <textarea name="description" placeholder="Product Description"></textarea>
            <button type="submit" class="add-btn">Add Product</button>
        </form>

        <!-- PRODUCT LIST TABLE -->
        <table>
            <tr>
                <th>ID</th>
                <th>Image</th>
                <th>Name</th>
                <th>Brand</th>
                <th>Price</th>
                <th>Stock</th>
                <th>Actions</th>
            </tr>
            <?php if ($result_products->num_rows > 0): ?>
                <?php while ($row = $result_products->fetch_assoc()): ?>
                    <tr>
                        <td><?php echo htmlspecialchars($row['id']); ?></td>
                        <td>
                            <img src="<?php echo !empty($row['image']) ? htmlspecialchars($row['image']) : 'images/default.jpg'; ?>"
                                width="50"
                                alt="Product Image"
                                onerror="this.src='images/default.jpg';">
                        </td>
                        <td><?php echo htmlspecialchars($row['name']); ?></td>
                        <td><?php echo htmlspecialchars($row['brand']); ?></td>
                        <td>₱<?php echo number_format($row['price'], 2); ?></td>
                        <td><?php echo htmlspecialchars($row['stock']); ?></td>
                        <td>
                            <form action="ProductHandler.php" method="post">
                                <input type="hidden" name="id" value="<?php echo htmlspecialchars($row['id']); ?>">
                                <button type="submit" name="action" value="edit" class="edit-btn">Edit</button>
                                <button type="submit" name="action" value="delete" class="delete-btn" onclick="return confirm('Are you sure?')">Delete</button>
                            </form>
                        </td>
                    </tr>
                <?php endwhile; ?>
            <?php else: ?>
                <tr>
                    <td colspan="7" style="text-align: center;">No products found</td>
                </tr>
            <?php endif; ?>
        </table>

        <hr>

        <h1>Manage Customers</h1>

        <!-- ADD NEW CUSTOMER FORM -->
        <form action="CustomerHandler.php" method="post" class="form-container">
            <input type="hidden" name="action" value="add">
            <input type="text" name="full_name" placeholder="Full Name" required>
            <input type="email" name="email" placeholder="Email" required>
            <input type="password" name="password" placeholder="Password" required>
            <button type="submit" class="add-btn">Add Customer</button>
        </form>

        <!-- CUSTOMER LIST TABLE -->
        <table>
            <tr>
                <th>ID</th>
                <th>Full Name</th>
                <th>Email</th>
                <th>Actions</th>
            </tr>
            <?php while ($row = $result_customers->fetch_assoc()): ?>
                <tr>
                    <td><?php echo htmlspecialchars($row['id']); ?></td>
                    <td><?php echo htmlspecialchars($row['full_name']); ?></td>
                    <td><?php echo htmlspecialchars($row['email']); ?></td>
                    <td>
                        <form action="CustomerHandler.php" method="post">
                            <input type="hidden" name="id" value="<?php echo htmlspecialchars($row['id']); ?>">
                            <button type="submit" name="action" value="edit" class="edit-btn">Edit</button>
                            <button type="submit" name="action" value="delete" class="delete-btn" onclick="return confirm('Are you sure?')">Delete</button>
                        </form>
                    </td>
                </tr>
            <?php endwhile; ?>
        </table>
    </main>

    <?php include 'components/Footer.php'; ?>

</body>

</html>