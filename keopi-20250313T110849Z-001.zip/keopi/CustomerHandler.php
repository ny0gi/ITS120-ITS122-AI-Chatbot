<?php
session_start();
include 'db_connection.php';

// Check if user is an employee
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'employee') {
    echo "<script>alert('Access denied!'); window.location.href='Login.php';</script>";
    exit();
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $action = $_POST['action'];

    if ($action === "add") {
        $full_name = $_POST['full_name'];
        $email = $_POST['email'];
        $password = password_hash($_POST['password'], PASSWORD_DEFAULT); // Hash the password

        // Check if email already exists
        $check_sql = "SELECT id FROM users WHERE email = ?";
        $check_stmt = $conn->prepare($check_sql);
        $check_stmt->bind_param("s", $email);
        $check_stmt->execute();
        $result = $check_stmt->get_result();

        if ($result->num_rows > 0) {
            echo "<script>alert('Email already exists!'); window.location.href='dashboard.php';</script>";
            exit();
        }

        // Insert new customer
        $sql = "INSERT INTO users (full_name, email, password, role) VALUES (?, ?, ?, 'customer')";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("sss", $full_name, $email, $password);

        if ($stmt->execute()) {
            echo "<script>alert('Customer added successfully!'); window.location.href='dashboard.php';</script>";
        } else {
            echo "<script>alert('Error adding customer!'); window.location.href='dashboard.php';</script>";
        }
    } elseif ($action === "edit") {
        $id = $_POST['id'];
        $sql = "SELECT id, full_name, email FROM users WHERE id = ? AND role = 'customer'";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("i", $id);
        $stmt->execute();
        $result = $stmt->get_result()->fetch_assoc();

        if ($result) {
            echo "
            <!DOCTYPE html>
            <html lang='en'>
            <head>
                <meta charset='UTF-8'>
                <meta name='viewport' content='width=device-width, initial-scale=1.0'>
                <title>Edit Customer</title>
                <style>
                    body {
                        font-family: 'Poppins', sans-serif;
                        background-color: #f4f4f4;
                        margin: 0;
                        padding: 20px;
                    }
                    .edit-form-container {
                        max-width: 600px;
                        margin: 50px auto;
                        padding: 20px;
                        background: white;
                        border-radius: 10px;
                        box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.1);
                    }
                    .edit-form-container h2 {
                        text-align: center;
                        color: #333;
                        margin-bottom: 20px;
                    }
                    .form-group {
                        margin-bottom: 15px;
                    }
                    .form-group label {
                        display: block;
                        margin-bottom: 5px;
                        color: #555;
                    }
                    .form-group input {
                        width: 100%;
                        padding: 10px;
                        border: 1px solid #ddd;
                        border-radius: 5px;
                        font-size: 16px;
                    }
                    .update-btn, .cancel-btn {
                        padding: 10px 15px;
                        border: none;
                        border-radius: 5px;
                        cursor: pointer;
                        font-size: 16px;
                        margin-right: 10px;
                    }
                    .update-btn {
                        background-color: #FF9800;
                        color: white;
                    }
                    .update-btn:hover {
                        background-color: #FFC107;
                    }
                    .cancel-btn {
                        background-color: #F44336;
                        color: white;
                    }
                    .cancel-btn:hover {
                        background-color: #E57373;
                    }
                </style>
            </head>
            <body>
                <div class='edit-form-container'>
                    <h2>Edit Customer</h2>
                    <form action='CustomerHandler.php' method='post'>
                        <input type='hidden' name='action' value='update'>
                        <input type='hidden' name='id' value='" . htmlspecialchars($result['id']) . "'>
                        
                        <div class='form-group'>
                            <label for='full_name'>Full Name:</label>
                            <input type='text' id='full_name' name='full_name' value='" . htmlspecialchars($result['full_name']) . "' required>
                        </div>
                        
                        <div class='form-group'>
                            <label for='email'>Email:</label>
                            <input type='email' id='email' name='email' value='" . htmlspecialchars($result['email']) . "' required>
                        </div>
                        
                        <div class='form-group'>
                            <label for='password'>New Password (leave blank to keep current):</label>
                            <input type='password' id='password' name='password'>
                        </div>
                        
                        <button type='submit' class='update-btn'>Update Customer</button>
                        <button type='button' onclick='window.location.href=\"dashboard.php\"' class='cancel-btn'>Cancel</button>
                    </form>
                </div>
            </body>
            </html>";
        }
    } elseif ($action === "update") {
        $id = $_POST['id'];
        $full_name = $_POST['full_name'];
        $email = $_POST['email'];

        // Check if email exists for other users
        $check_sql = "SELECT id FROM users WHERE email = ? AND id != ?";
        $check_stmt = $conn->prepare($check_sql);
        $check_stmt->bind_param("si", $email, $id);
        $check_stmt->execute();
        $result = $check_stmt->get_result();

        if ($result->num_rows > 0) {
            echo "<script>alert('Email already exists!'); window.location.href='dashboard.php';</script>";
            exit();
        }

        if (!empty($_POST['password'])) {
            // Update with new password
            $password = password_hash($_POST['password'], PASSWORD_DEFAULT);
            $sql = "UPDATE users SET full_name = ?, email = ?, password = ? WHERE id = ? AND role = 'customer'";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("sssi", $full_name, $email, $password, $id);
        } else {
            // Update without changing password
            $sql = "UPDATE users SET full_name = ?, email = ? WHERE id = ? AND role = 'customer'";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("ssi", $full_name, $email, $id);
        }

        if ($stmt->execute()) {
            echo "<script>alert('Customer updated successfully!'); window.location.href='dashboard.php';</script>";
        } else {
            echo "<script>alert('Error updating customer!'); window.location.href='dashboard.php';</script>";
        }
    } elseif ($action === "delete") {
        $id = $_POST['id'];

        // Only delete if the user is a customer
        $sql = "DELETE FROM users WHERE id = ? AND role = 'customer'";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("i", $id);

        if ($stmt->execute()) {
            echo "<script>alert('Customer deleted successfully!'); window.location.href='dashboard.php';</script>";
        } else {
            echo "<script>alert('Error deleting customer!'); window.location.href='dashboard.php';</script>";
        }
    }
}
