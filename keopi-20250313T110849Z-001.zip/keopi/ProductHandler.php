<?php
session_start();
include 'db_connection.php';

// Check if user is an employee
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'employee') {
    echo "<script>alert('Access denied!'); window.location.href='Login.php';</script>";
    exit();
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $action = $_POST['action'];

    if ($action === "add") {
        try {
            $name = $_POST['name'];
            $price = $_POST['price'];
            $stock = $_POST['stock'];
            $description = $_POST['description'];
            $brand = $_POST['brand'];

            // Debug log
            error_log("Adding product - Name: $name, Brand: $brand, Price: $price, Stock: $stock");

            // Handle image upload
            if (isset($_FILES['image']) && $_FILES['image']['error'] === UPLOAD_ERR_OK) {
                $image = "images/" . basename($_FILES['image']['name']);
                $target = $image;

                // Create images directory if it doesn't exist
                if (!file_exists('images')) {
                    mkdir('images', 0777, true);
                }

                // Move the uploaded file
                if (!move_uploaded_file($_FILES['image']['tmp_name'], $target)) {
                    throw new Exception("Failed to move uploaded file.");
                }
                error_log("Image uploaded successfully to: $target");
            } else {
                error_log("Image upload error: " . $_FILES['image']['error']);
                throw new Exception("No image uploaded or upload error occurred.");
            }

            // Insert into database
            $sql = "INSERT INTO products (name, price, stock, image, description, brand) VALUES (?, ?, ?, ?, ?, ?)";
            error_log("SQL Query: $sql");

            $stmt = $conn->prepare($sql);
            if (!$stmt) {
                error_log("Prepare failed: " . $conn->error);
                throw new Exception("Prepare failed: " . $conn->error);
            }

            error_log("Binding parameters - Name: $name, Price: $price, Stock: $stock, Image: $image, Brand: $brand");
            $stmt->bind_param("sdisss", $name, $price, $stock, $image, $description, $brand);

            if (!$stmt->execute()) {
                error_log("Execute failed: " . $stmt->error);
                throw new Exception("Execute failed: " . $stmt->error);
            }

            // Log the inserted ID
            $last_id = $conn->insert_id;
            error_log("Product inserted successfully with ID: $last_id");

            echo "<script>alert('Product added successfully! ID: $last_id'); window.location.href='dashboard.php';</script>";
        } catch (Exception $e) {
            error_log("Error in ProductHandler.php: " . $e->getMessage());
            echo "<script>alert('Error: " . addslashes($e->getMessage()) . "'); window.location.href='dashboard.php';</script>";
        }
    } elseif ($action === "edit") {
        try {
            $id = $_POST['id'];
            $sql = "SELECT * FROM products WHERE id=?";
            $stmt = $conn->prepare($sql);
            if (!$stmt) {
                throw new Exception("Prepare failed: " . $conn->error);
            }

            $stmt->bind_param("i", $id);
            $stmt->execute();
            $result = $stmt->get_result()->fetch_assoc();

            if (!$result) {
                throw new Exception("Product not found.");
            }

            echo "
            <!DOCTYPE html>
            <html lang='en'>
            <head>
                <meta charset='UTF-8'>
                <meta name='viewport' content='width=device-width, initial-scale=1.0'>
                <title>Edit Product</title>
                <style>
                    body {
                        font-family: 'Poppins', sans-serif;
                        background-color: #f4f4f4;
                        margin: 0;
                        padding: 20px;
                    }
                    .edit-form-container {
                        max-width: 600px;
                        margin: 50px auto;
                        padding: 20px;
                        background: white;
                        border-radius: 10px;
                        box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.1);
                    }
                    .edit-form-container h2 {
                        text-align: center;
                        color: #333;
                        margin-bottom: 20px;
                    }
                    .form-group {
                        margin-bottom: 15px;
                    }
                    .form-group label {
                        display: block;
                        margin-bottom: 5px;
                        color: #555;
                    }
                    .form-group input,
                    .form-group select,
                    .form-group textarea {
                        width: 100%;
                        padding: 10px;
                        border: 1px solid #ddd;
                        border-radius: 5px;
                        font-size: 16px;
                    }
                    .form-group textarea {
                        height: 100px;
                    }
                    .form-group img {
                        max-width: 100px;
                        margin-top: 10px;
                    }
                    .update-btn, .cancel-btn {
                        padding: 10px 15px;
                        border: none;
                        border-radius: 5px;
                        cursor: pointer;
                        font-size: 16px;
                        margin-right: 10px;
                    }
                    .update-btn {
                        background-color: #FF9800;
                        color: white;
                    }
                    .update-btn:hover {
                        background-color: #FFC107;
                    }
                    .cancel-btn {
                        background-color: #F44336;
                        color: white;
                    }
                    .cancel-btn:hover {
                        background-color: #E57373;
                    }
                </style>
            </head>
            <body>
                <div class='edit-form-container'>
                    <h2>Edit Product</h2>
                    <form action='ProductHandler.php' method='post' enctype='multipart/form-data'>
                        <input type='hidden' name='action' value='update'>
                        <input type='hidden' name='id' value='" . htmlspecialchars($result['id']) . "'>
                        
                        <div class='form-group'>
                            <label for='name'>Product Name:</label>
                            <input type='text' id='name' name='name' value='" . htmlspecialchars($result['name']) . "' required>
                        </div>

                        <div class='form-group'>
                            <label for='brand'>Brand:</label>
                            <select name='brand' id='brand' required>
                                <option value='Samsung'" . ($result['brand'] == 'Samsung' ? ' selected' : '') . ">Samsung</option>
                                <option value='Apple'" . ($result['brand'] == 'Apple' ? ' selected' : '') . ">Apple</option>
                                <option value='Oppo'" . ($result['brand'] == 'Oppo' ? ' selected' : '') . ">Oppo</option>
                                <option value='Xiaomi'" . ($result['brand'] == 'Xiaomi' ? ' selected' : '') . ">Xiaomi</option>
                                <option value='Oneplus'" . ($result['brand'] == 'Oneplus' ? ' selected' : '') . ">OnePlus</option>
                            </select>
                        </div>

                        <div class='form-group'>
                            <label for='price'>Price:</label>
                            <input type='number' id='price' name='price' value='" . htmlspecialchars($result['price']) . "' required>
                        </div>

                        <div class='form-group'>
                            <label for='stock'>Stock:</label>
                            <input type='number' id='stock' name='stock' value='" . htmlspecialchars($result['stock']) . "' required>
                        </div>

                        <div class='form-group'>
                            <label for='image'>Image (leave empty to keep current):</label>
                            <input type='file' id='image' name='image'>
                            <img src='" . htmlspecialchars($result['image']) . "' alt='Current image'>
                        </div>

                        <div class='form-group'>
                            <label for='description'>Description:</label>
                            <textarea id='description' name='description'>" . htmlspecialchars($result['description']) . "</textarea>
                        </div>

                        <button type='submit' class='update-btn'>Update Product</button>
                        <button type='button' onclick='window.location.href=\"dashboard.php\"' class='cancel-btn'>Cancel</button>
                    </form>
                </div>
            </body>
            </html>";
        } catch (Exception $e) {
            error_log("Error in ProductHandler.php: " . $e->getMessage());
            echo "<script>alert('Error: " . addslashes($e->getMessage()) . "'); window.location.href='dashboard.php';</script>";
        }
    } elseif ($action === "update") {
        try {
            $id = $_POST['id'];
            $name = $_POST['name'];
            $price = $_POST['price'];
            $stock = $_POST['stock'];
            $description = $_POST['description'];
            $brand = $_POST['brand'];

            // Handle image upload if a new image is provided
            if (!empty($_FILES['image']['name'])) {
                $image = "images/" . basename($_FILES['image']['name']);
                $target = $image;

                // Create images directory if it doesn't exist
                if (!file_exists('images')) {
                    mkdir('images', 0777, true);
                }

                if (!move_uploaded_file($_FILES['image']['tmp_name'], $target)) {
                    throw new Exception("Failed to move uploaded file.");
                }

                $sql = "UPDATE products SET name=?, price=?, stock=?, description=?, brand=?, image=? WHERE id=?";
                $stmt = $conn->prepare($sql);
                if (!$stmt) {
                    throw new Exception("Prepare failed: " . $conn->error);
                }
                $stmt->bind_param("sdsssi", $name, $price, $stock, $description, $brand, $image, $id);
            } else {
                $sql = "UPDATE products SET name=?, price=?, stock=?, description=?, brand=? WHERE id=?";
                $stmt = $conn->prepare($sql);
                if (!$stmt) {
                    throw new Exception("Prepare failed: " . $conn->error);
                }
                $stmt->bind_param("sdsssi", $name, $price, $stock, $description, $brand, $id);
            }

            if (!$stmt->execute()) {
                throw new Exception("Execute failed: " . $stmt->error);
            }

            echo "<script>alert('Product updated successfully!'); window.location.href='dashboard.php';</script>";
        } catch (Exception $e) {
            error_log("Error in ProductHandler.php: " . $e->getMessage());
            echo "<script>alert('Error: " . addslashes($e->getMessage()) . "'); window.location.href='dashboard.php';</script>";
        }
    } elseif ($action === "delete") {
        try {
            $id = $_POST['id'];

            // Get the image path before deleting
            $sql = "SELECT image FROM products WHERE id = ?";
            $stmt = $conn->prepare($sql);
            if (!$stmt) {
                throw new Exception("Prepare failed: " . $conn->error);
            }
            $stmt->bind_param("i", $id);
            $stmt->execute();
            $result = $stmt->get_result()->fetch_assoc();

            // Delete the product
            $sql = "DELETE FROM products WHERE id = ?";
            $stmt = $conn->prepare($sql);
            if (!$stmt) {
                throw new Exception("Prepare failed: " . $conn->error);
            }
            $stmt->bind_param("i", $id);

            if (!$stmt->execute()) {
                throw new Exception("Execute failed: " . $stmt->error);
            }

            // Delete the image file if it exists
            if ($result && !empty($result['image']) && file_exists($result['image'])) {
                unlink($result['image']);
            }

            echo "<script>alert('Product deleted successfully!'); window.location.href='dashboard.php';</script>";
        } catch (Exception $e) {
            error_log("Error in ProductHandler.php: " . $e->getMessage());
            echo "<script>alert('Error: " . addslashes($e->getMessage()) . "'); window.location.href='dashboard.php';</script>";
        }
    }
}
