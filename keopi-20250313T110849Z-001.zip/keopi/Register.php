<?php
    // Register.php
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Jaden’s Online Phone Shop - Register</title>
    <link rel="stylesheet" href="Register.css">
    
    <script>
        function toggleForm(role) {
            document.getElementById('customer-form').classList.toggle('hidden', role !== 'customer');
            document.getElementById('employee-form').classList.toggle('hidden', role !== 'employee');
            document.getElementById('customer-tab').classList.toggle('active', role === 'customer');
            document.getElementById('employee-tab').classList.toggle('active', role === 'employee');
        }

        // Ensure correct tab is visible on page load
        document.addEventListener("DOMContentLoaded", function () {
            toggleForm('customer'); // Default to customer registration
        });
    </script>
</head>
<body>

<?php include 'components/Header.php'; ?>

<main>
    <h1>Register</h1>
    <div class="tab-container">
        <button id="customer-tab" class="tab active" onclick="toggleForm('customer')">Register as Customer</button>
        <button id="employee-tab" class="tab" onclick="toggleForm('employee')">Register as Employee</button>
    </div>

    <!-- Customer Registration Form -->
    <div id="customer-form" class="form-container">
        <form action="RegisterHandler.php" method="post">
            <input type="hidden" name="role" value="customer">
            
            <div class="form-group">
                <label for="customer-email">Email</label>
                <input type="email" id="customer-email" name="email" required>
            </div>

            <div class="form-group">
                <label for="customer-full_name">Full Name</label>
                <input type="text" id="customer-full_name" name="full_name" required>
            </div>
            
            <div class="form-group">
                <label for="customer-password">Password</label>
                <input type="password" id="customer-password" name="password" required>
            </div>

            <div class="form-group">
                <label for="customer-address">Address</label>
                <input type="text" id="customer-address" name="address" required>
            </div>

            <div class="form-group">
                <label for="customer-contact_number">Contact Number</label>
                <input type="text" id="customer-contact_number" name="contact_number" required>
            </div>

            <button type="submit" class="register">Register Now</button>
        </form>
    </div>

    <!-- Employee Registration Form -->
    <div id="employee-form" class="form-container hidden">
        <form action="RegisterHandler.php" method="post">
            <input type="hidden" name="role" value="employee">
            
            <div class="form-group">
                <label for="employee-email">Email</label>
                <input type="email" id="employee-email" name="email" required>
            </div>

            <div class="form-group">
                <label for="employee-full_name">Full Name</label>
                <input type="text" id="employee-full_name" name="full_name" required>
            </div>

            <div class="form-group">
                <label for="employee-password">Password</label>
                <input type="password" id="employee-password" name="password" required>
            </div>

            <div class="form-group">
                <label for="employee-address">Address</label>
                <input type="text" id="employee-address" name="address" required>
            </div>

            <div class="form-group">
                <label for="employee-contact_number">Contact Number</label>
                <input type="text" id="employee-contact_number" name="contact_number" required>
            </div>

            <button type="submit" class="register">Register Now</button>
        </form>
    </div>

    <p>Already have an account? <a href="Login.php">Sign in</a></p>
</main>

<?php include 'components/Footer.php'; ?>

</body>
</html>
