<?php
    // Reports.php
    $current_page = 'Reports';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Jaden’s Online Phone Shop  - Reports</title>
    <link rel="stylesheet" href="Reports.css">
    
</head>
<body>

<?php include 'components/Header.php'; ?>

<div class="reports-container">
    <h1>Reports</h1>

    <div class="report-card">
        <h2>Sales Report</h2>
        <p>Overview of daily, weekly, and monthly sales data.</p>
    </div>

    <div class="report-card">
        <h2>Inventory Report</h2>
        <p>Detailed view of current stock levels and low-stock alerts.</p>
    </div>

    <div class="report-card">
        <h2>User Activity Report</h2>
        <p>Summary of user interactions and account activity.</p>
    </div>

</div>

<?php include 'components/Footer.php'; ?>

</body>
</html>
