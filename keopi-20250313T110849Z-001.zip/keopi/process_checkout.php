<?php
// Enable error reporting
error_reporting(E_ALL);
ini_set('display_errors', 1);

session_start();
include 'db_connection.php';

// Function to redirect with error message
function redirectWithError($message, $location) {
    echo "<script>
        alert('" . addslashes($message) . "');
        window.location.href='" . $location . "';
    </script>";
    exit();
}

if (!isset($_SESSION['user_id'])) {
    redirectWithError('Please login first!', 'login.php');
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        // Start transaction
        $conn->begin_transaction();

        // Get cart items from session
        if (isset($_SESSION['cart']) && !empty($_SESSION['cart'])) {
            $orderSuccess = true;
            $errors = [];

            foreach ($_SESSION['cart'] as $product_id => $item) {
                // Check current stock
                $stock_check = "SELECT stock FROM products WHERE id = ?";
                $stmt = $conn->prepare($stock_check);
                if (!$stmt) {
                    throw new Exception("Database error: " . $conn->error);
                }
                $stmt->bind_param("i", $product_id);
                if (!$stmt->execute()) {
                    throw new Exception("Error checking stock: " . $stmt->error);
                }
                $result = $stmt->get_result();
                $product = $result->fetch_assoc();

                if (!$product) {
                    throw new Exception("Product not found: ID " . $product_id);
                }

                if ($product['stock'] < $item['quantity']) {
                    throw new Exception("Not enough stock for " . $item['name'] . ". Available: " . $product['stock']);
                }

                // Update product stock
                $new_stock = $product['stock'] - $item['quantity'];
                $update_stock = "UPDATE products SET stock = ? WHERE id = ?";
                $stmt = $conn->prepare($update_stock);
                if (!$stmt) {
                    throw new Exception("Database error: " . $conn->error);
                }
                $stmt->bind_param("ii", $new_stock, $product_id);
                if (!$stmt->execute()) {
                    throw new Exception("Error updating stock: " . $stmt->error);
                }

                // Record the order
                $total_price = $item['price'] * $item['quantity'];
                $insert_order = "INSERT INTO orders (user_id, product_id, quantity, total_price) VALUES (?, ?, ?, ?)";
                $stmt = $conn->prepare($insert_order);
                if (!$stmt) {
                    throw new Exception("Database error: " . $conn->error);
                }
                $stmt->bind_param("iiid", $_SESSION['user_id'], $product_id, $item['quantity'], $total_price);
                if (!$stmt->execute()) {
                    throw new Exception("Error recording order: " . $stmt->error);
                }
            }

            // If everything is successful, commit the transaction
            $conn->commit();
            
            // Clear the cart
            unset($_SESSION['cart']);
            
            redirectWithError('Order placed successfully!', 'account.php');
        } else {
            redirectWithError('Your cart is empty!', 'cart.php');
        }
    } catch (Exception $e) {
        // If there's an error, rollback the transaction
        $conn->rollback();
        redirectWithError('Error: ' . $e->getMessage(), 'cart.php');
    }
} else {
    // If not POST request, redirect to cart
    redirectWithError('Invalid request method!', 'cart.php');
}
?> 