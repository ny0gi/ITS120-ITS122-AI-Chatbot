<?php
session_start();

// Check if user is logged in and is an employee
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'employee') {
    header("Location: login.php");
    exit();
}

include 'db_connection.php';

// Fetch all orders with user and product details
$sql = "SELECT o.*, p.name as product_name, p.image, u.full_name as customer_name, u.email as customer_email 
        FROM orders o 
        JOIN products p ON o.product_id = p.id 
        JOIN users u ON o.user_id = u.id 
        ORDER BY o.order_date DESC";
$result = $conn->query($sql);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Transactions - Jaden's Online Phone Shop</title>
    <link rel="stylesheet" href="Account.css">
    <style>
        .transactions-container {
            max-width: 1200px;
            margin: 2rem auto;
            padding: 0 1rem;
        }
        .order-table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
            background-color: white;
            box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1);
        }
        .order-table th, .order-table td {
            padding: 15px;
            text-align: left;
            border-bottom: 1px solid #ddd;
        }
        .order-table th {
            background-color: #FF5722;
            color: white;
            font-weight: bold;
        }
        .order-table tr:hover {
            background-color: #f9f9f9;
        }
        .product-image {
            width: 60px;
            height: 60px;
            object-fit: contain;
        }
        .table-responsive {
            overflow-x: auto;
            margin-top: 20px;
        }
        .page-title {
            color: #333;
            margin-bottom: 1rem;
            text-align: center;
        }
        .transaction-summary {
            background-color: white;
            padding: 20px;
            border-radius: 5px;
            box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1);
            margin-bottom: 20px;
        }
        .summary-item {
            display: inline-block;
            margin-right: 30px;
            padding: 10px 20px;
            background-color: #f5f5f5;
            border-radius: 5px;
        }
        .summary-item strong {
            color: #FF5722;
        }
        @media (max-width: 768px) {
            .order-table {
                font-size: 14px;
            }
            .order-table th, .order-table td {
                padding: 10px;
            }
            .product-image {
                width: 40px;
                height: 40px;
            }
        }
    </style>
</head>
<body>

<?php include 'components/Header.php'; ?>

<main>
    <div class="transactions-container">
        <h1 class="page-title">Transaction History</h1>

        <div class="transaction-summary">
            <div class="summary-item">
                <strong>Total Orders:</strong> <?php echo $result->num_rows; ?>
            </div>
            <?php
            // Calculate total revenue
            $total_revenue = 0;
            if ($result->num_rows > 0) {
                $temp_result = $result;
                while($row = $temp_result->fetch_assoc()) {
                    $total_revenue += $row['total_price'];
                }
                // Reset the result pointer
                $result->data_seek(0);
            }
            ?>
            <div class="summary-item">
                <strong>Total Revenue:</strong> ₱<?php echo number_format($total_revenue, 2); ?>
            </div>
        </div>

        <?php if ($result->num_rows > 0): ?>
            <div class="table-responsive">
                <table class="order-table">
                    <thead>
                        <tr>
                            <th>Order Date</th>
                            <th>Customer</th>
                            <th>Product</th>
                            <th>Image</th>
                            <th>Quantity</th>
                            <th>Total Price</th>
                            <th>Status</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php while ($order = $result->fetch_assoc()): ?>
                            <tr>
                                <td><?php echo date('M d, Y H:i', strtotime($order['order_date'])); ?></td>
                                <td>
                                    <?php echo htmlspecialchars($order['customer_name']); ?><br>
                                    <small><?php echo htmlspecialchars($order['customer_email']); ?></small>
                                </td>
                                <td><?php echo htmlspecialchars($order['product_name']); ?></td>
                                <td><img class="product-image" src="<?php echo htmlspecialchars($order['image']); ?>" alt="<?php echo htmlspecialchars($order['product_name']); ?>"></td>
                                <td><?php echo htmlspecialchars($order['quantity']); ?></td>
                                <td>₱<?php echo number_format($order['total_price'], 2); ?></td>
                                <td>Ordered</td>
                            </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>
            </div>
        <?php else: ?>
            <p class="no-orders">No transactions found.</p>
        <?php endif; ?>
    </div>
</main>

<?php include 'components/Footer.php'; ?>

</body>
</html> 