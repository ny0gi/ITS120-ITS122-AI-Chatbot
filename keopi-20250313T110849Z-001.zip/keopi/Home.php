<?php
session_start(); // Start the session
$current_page = 'Home';

// Check if user is logged in
$is_logged_in = isset($_SESSION['user_id']);

// Home.php
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Jaden's Online Phone Shop - Home</title>
    <link rel="stylesheet" href="Home.css">
</head>

<body>

    <?php include 'components/Header.php'; ?>

    <main>
        <div class="hero">
            <h1>Welcome to Jaden's Online Phone Shop</h1>
            <p>Your one-stop shop for the latest and greatest phones. Explore our wide selection today!</p>
            <button onclick="window.location.href='Products.php'">Shop Now</button>
        </div>

        <?php if ($is_logged_in): ?>
            <div class="logout-container">
                <p>Welcome, <?php echo htmlspecialchars($_SESSION['full_name']); ?>!</p>
            </div>
        <?php endif; ?>

        <!-- Chatbot Container -->
        <div class="chatbot-container">
            <iframe
                src="https://www.chatbase.co/chatbot-iframe/ZKnGPKHZBRuNpnlPB-A6v"
                width="100%"
                style="height: 500px; border-radius: 10px; box-shadow: 0 2px 4px rgba(0,0,0,0.1);"
                frameborder="0"
            ></iframe>
        </div>

        <section class="features">
            <div class="feature">
                <img src="assets/samsung_selection.avif" alt="Latest Samsung Phones">
                <h2>Samsung Phones</h2>
                <p>Experience innovation with the latest Samsung Galaxy devices.</p>
            </div>

            <div class="feature">
                <img src="assets/iphone_selection.png" alt="iPhones">
                <h2>iPhones</h2>
                <p>Discover the power of Apple with cutting-edge iPhones.</p>
            </div>

            <div class="feature">
                <img src="assets/accessories_selection.jpg" alt="Accessories">
                <h2>Accessories</h2>
                <p>Enhance your experience with our premium accessories.</p>
            </div>
        </section>
    </main>

    <?php include 'components/Footer.php'; ?>

    <!-- Chat Head Script -->
    <script>
    (function(){if(!window.chatbase||window.chatbase("getState")!=="initialized"){window.chatbase=(...arguments)=>{if(!window.chatbase.q){window.chatbase.q=[]}window.chatbase.q.push(arguments)};window.chatbase=new Proxy(window.chatbase,{get(target,prop){if(prop==="q"){return target.q}return(...args)=>target(prop,...args)}})}const onLoad=function(){const script=document.createElement("script");script.src="https://www.chatbase.co/embed.min.js";script.id="ZKnGPKHZBRuNpnlPB-A6v";script.domain="www.chatbase.co";document.body.appendChild(script)};if(document.readyState==="complete"){onLoad()}else{window.addEventListener("load",onLoad)}})();
    </script>
</body>

</html>
