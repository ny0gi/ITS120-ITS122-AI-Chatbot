<?php
session_start();

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

include 'db_connection.php';

// Fetch orders only if user is a customer
$orders = null;
if ($_SESSION['role'] === 'customer') {
    $sql = "SELECT o.*, p.name as product_name, p.image 
            FROM orders o 
            JOIN products p ON o.product_id = p.id 
            WHERE o.user_id = ? 
            ORDER BY o.order_date DESC";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $_SESSION['user_id']);
    $stmt->execute();
    $orders = $stmt->get_result();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Account - Jaden's Online Phone Shop</title>
    <link rel="stylesheet" href="Account.css">
    <style>
    .order-table {
        width: 100%;
        border-collapse: collapse;
        margin-top: 20px;
        background-color: white;
        box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1);
        border-spacing: 10px;
    }
    .order-table th, .order-table td {
        padding: 15px;
        text-align: left;
        border-bottom: 1px solid #ddd;
    }
    .order-table th {
        background-color: #f5f5f5;
        font-weight: bold;
        color: #333;
    }
    .order-table tr:hover {
        background-color: #f9f9f9;
    }
    .product-image {
        width: 60px;
        height: 60px;
        object-fit: contain;
    }
    .account-actions {
        margin-top: 30px;
        text-align: center;
    }
    .logout-button {
        padding: 12px 20px;
        background-color: #d9534f;
        color: white;
        border: none;
        border-radius: 5px;
        cursor: pointer;
        font-size: 16px;
        margin-top: 15px;
    }
    .logout-button:hover {
        background-color: #c9302c;
    }
</style>

</head>
<body>

<?php include 'components/Header.php'; ?>

<main>
    <div class="account-container">
        <h1>My Account</h1>
        
        <div class="user-info">
            <h2>Welcome, <?php echo htmlspecialchars($_SESSION['full_name']); ?>!</h2>
            <p><strong>Email:</strong> <?php echo htmlspecialchars($_SESSION['email']); ?></p>
            <p><strong>Role:</strong> <?php echo ucfirst(htmlspecialchars($_SESSION['role'])); ?></p>
        </div>

        <?php if ($_SESSION['role'] === 'customer'): ?>
            <div class="order-history">
                <h2>Order History</h2>
                <?php if ($orders && $orders->num_rows > 0): ?>
                    <div class="table-responsive">
                        <table class="order-table">
                            <thead>
                                <tr>
                                    <th>Product</th>
                                    <th>Image</th>
                                    <th>Quantity</th>
                                    <th>Total Price</th>
                                    <th>Order Date</th>
                                    <th>Status</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php while ($order = $orders->fetch_assoc()): ?>
                                    <tr>
                                        <td><?php echo htmlspecialchars($order['product_name']); ?></td>
                                        <td><img class="product-image" src="<?php echo htmlspecialchars($order['image']); ?>" alt="<?php echo htmlspecialchars($order['product_name']); ?>"></td>
                                        <td><?php echo htmlspecialchars($order['quantity']); ?></td>
                                        <td>₱<?php echo number_format($order['total_price'], 2); ?></td>
                                        <td><?php echo date('M d, Y H:i', strtotime($order['order_date'])); ?></td>
                                        <td>Ordered</td>
                                    </tr>
                                <?php endwhile; ?>
                            </tbody>
                        </table>
                    </div>
                <?php else: ?>
                    <p class="no-orders">No orders yet.</p>
                <?php endif; ?>
            </div>
        <?php endif; ?>

        <div class="account-actions">
            <form action="logout.php" method="post">
                <button type="submit" class="logout-button">Logout</button>
            </form>
        </div>
    </div>
</main>

<?php include 'components/Footer.php'; ?>

</body>
</html>
