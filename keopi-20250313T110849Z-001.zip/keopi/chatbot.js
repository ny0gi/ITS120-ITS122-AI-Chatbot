document.addEventListener("DOMContentLoaded", function () {
    let userInput = document.getElementById("user-input");
    let chatBox = document.getElementById("chat-box");

    function sendMessage() {
        if (userInput.value.trim() !== "") {
            // Create user message
            let userMessage = document.createElement("div");
            userMessage.textContent = userInput.value;
            userMessage.classList.add("user-message");
            chatBox.appendChild(userMessage);

            // Scroll to latest message
            chatBox.scrollTop = chatBox.scrollHeight;

            // Simulate AI response
            setTimeout(() => {
                generateAIResponse(userMessage.textContent);
            }, 1000);

            // Clear input field
            userInput.value = "";
        }
    }

    function generateAIResponse(userText) {
        let responses = {
            "hi": "Hello! How can I assist you today?",
            "iphone": "Looking for an iPhone? We have the latest models!",
            "samsung": "Samsung offers great choices! Any specific model?",
            "accessories": "We have cases, chargers, and more!",
            "price": "What is your budget? I'll recommend options!"
        };

        let responseText = responses[userText.toLowerCase()] || "I'm here to help! Ask me anything about our products.";

        // Create AI message
        let aiMessage = document.createElement("div");
        aiMessage.textContent = responseText;
        aiMessage.classList.add("ai-message");
        chatBox.appendChild(aiMessage);

        // Scroll to latest message
        chatBox.scrollTop = chatBox.scrollHeight;
    }

    userInput.addEventListener("keypress", function (event) {
        if (event.key === "Enter") {
            sendMessage();
        }
    });
});
