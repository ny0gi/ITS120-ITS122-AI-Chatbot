<?php
include 'db_connection.php';

if (!isset($_GET['id'])) {
    echo "<script>alert('Product not found!'); window.location.href='products.php';</script>";
    exit();
}

$id = $_GET['id'];
$sql = "SELECT * FROM products WHERE id=?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $id);
$stmt->execute();
$product = $stmt->get_result()->fetch_assoc();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $product['name']; ?> - Product Details</title>
    <link rel="stylesheet" href="product_details.css">
</head>
<body>

<?php include 'components/Header.php'; ?>

<main>
    <div class="product-detail">
        <img src="<?php echo $product['image']; ?>" alt="<?php echo $product['name']; ?>">
        <h1><?php echo $product['name']; ?></h1>
        <p><?php echo $product['description']; ?></p>
        <p><strong>Price:</strong> ₱<?php echo number_format($product['price'], 2); ?></p>
        <p><strong>Stock:</strong> <?php echo $product['stock']; ?></p>

        <?php if ($product['stock'] > 0): ?>
            <form action="cart.php" method="post">
                <input type="hidden" name="product_id" value="<?php echo $product['id']; ?>">
                <input type="number" name="quantity" value="1" min="1" max="<?php echo $product['stock']; ?>">
                <button type="submit">Add to Cart</button>
            </form>
        <?php else: ?>
            <p class="out-of-stock">Out of Stock</p>
        <?php endif; ?>
    </div>
</main>

<?php include 'components/Footer.php'; ?>

</body>
</html>
