<style>
    @import url('https://fonts.googleapis.com/css2?family=Poppins:wght@400;600&display=swap');

    body {
        font-family: 'Poppins', sans-serif;
        margin: 0;
        padding: 0;
        display: flex;
        flex-direction: column;
        min-height: 100vh;
    }

    main {
        padding: 20px;
        text-align: center;
    }

    header {
        background-color: #FF5722;
        color: white;
        padding: 1rem;
        display: flex;
        justify-content: space-between;
        align-items: center;
    }

    header h1 {
        margin: 0;
    }

    nav {
        background-color: #FF7043;
        color: white;
        display: flex;
        justify-content: center;
        padding: 0.5rem 0;
    }

    nav a {
        color: white;
        text-decoration: none;
        margin: 0 15px;
        font-weight: bold;
        padding: 5px 10px;
        border-radius: 5px;
    }

    nav a:hover {
        background-color: #FFAB91;
    }

    nav a.active {
        background-color: #FF8A65;
    }

    .account {
        margin-right: 15px;
    }
</style>