<?php
$servername = "localhost";
$username = "root";  // Change this if needed
$password = "";      // Change this if you have a password set
$dbname = "keopi_db"; // Your database name

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
?>
