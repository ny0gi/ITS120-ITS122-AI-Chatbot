<?php
include 'db_connection.php'; // Include the database connection

if (isset($_POST['email'], $_POST['password'], $_POST['full_name'], $_POST['address'], $_POST['contact_number'], $_POST['role'])) {
    $email = $_POST['email'];
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT); // Hash password securely
    $full_name = $_POST['full_name'];
    $address = $_POST['address'];
    $contact_number = $_POST['contact_number'];
    $role = $_POST['role']; // Either 'user' or 'employee'

    // Prepare the SQL statement
    $sql = "INSERT INTO users (email, password, full_name, address, contact_number, role) VALUES (?, ?, ?, ?, ?, ?)";
    $stmt = $conn->prepare($sql);

    if ($stmt === false) {
        die("Error preparing statement: " . $conn->error);
    }

    $stmt->bind_param("ssssss", $email, $password, $full_name, $address, $contact_number, $role);

    // Execute the statement and check for success
    if ($stmt->execute()) {
        echo "<script>
                alert('Registration Successful!');
                window.location.href = 'Login.php';
              </script>";
    } else {
        echo "<script>
                alert('Error: Registration failed. Please try again.');
                window.location.href = 'Register.php';
              </script>";
    }

    // Close statement and connection
    $stmt->close();
    $conn->close();
} else {
    echo "<script>
            alert('Missing required fields. Please fill out the form completely.');
            window.location.href = 'Register.php';
          </script>";
}
?>
